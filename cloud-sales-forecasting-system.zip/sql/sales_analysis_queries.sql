-- Total Monthly Sales
SELECT DATE_TRUNC('month', date) AS month, 
       SUM(units_sold * unit_price) AS total_sales
FROM sales
GROUP BY month
ORDER BY month;

-- Top Products by Revenue
SELECT product, SUM(units_sold * unit_price) AS revenue
FROM sales
GROUP BY product
ORDER BY revenue DESC;
