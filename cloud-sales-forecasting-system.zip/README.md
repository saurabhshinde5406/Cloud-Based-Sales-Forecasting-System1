# 📊 Cloud-Based Sales Forecasting System

A data analytics project to forecast future sales using SQL, Python, and Power BI hosted on a cloud-based data setup (AWS RDS).

## 🧰 Tech Stack
- SQL (PostgreSQL/MySQL on AWS RDS)
- Python (Pandas, scikit-learn)
- Power BI

## 📁 Folder Structure
dataset/               → Raw sales data in CSV  
sql/                   → SQL queries for trend analysis  
notebooks/             → Python notebook for forecasting model  
powerbi/               → Dashboard file (.pbix)

## 🔧 Features
- Sales trend analysis by region/product
- 3-month future sales forecast
- Power BI dashboard integration

## 📈 How to Use
1. Upload CSV to AWS RDS or local SQL DB
2. Run SQL queries for summary reports
3. Train regression model using Python
4. Build interactive visuals in Power BI
